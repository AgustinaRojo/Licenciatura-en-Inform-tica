// script.js

const materias = {};

const data = [
  {
    seccion: "Ciclo Introductorio",
    materias: [
      { nombre: "Elementos de programación" },
      { nombre: "Lectura y escritura académica" },
      { nombre: "Matemática" }
    ]
  },
  {
    seccion: "Primer Año - Segundo Cuatrimestre",
    materias: [
      { nombre: "Matemática I", prerequisitos: ["Elementos de programación", "Lectura y escritura académica", "Matemática"] },
      { nombre: "Introducción a la Programación", prerequisitos: ["Elementos de programación", "Lectura y escritura académica", "Matemática"] },
      { nombre: "Organización de Computadoras", prerequisitos: ["Elementos de programación", "Lectura y escritura académica", "Matemática"] }
    ]
  },
  {
    seccion: "Segundo Año - Tercer Cuatrimestre",
    materias: [
      { nombre: "Estructura de Datos", prerequisitos: ["Introducción a la Programación"] },
      { nombre: "Programación con Objetos I", prerequisitos: ["Introducción a la Programación"] },
      { nombre: "Bases de Datos", prerequisitos: ["Elementos de programación"] }
    ]
  },
  {
    seccion: "Segundo Año - Cuarto Cuatrimestre",
    materias: [
      { nombre: "Matemática II", prerequisitos: ["Matemática I"] },
      { nombre: "Programación con Objetos II", prerequisitos: ["Programación con Objetos I"] },
      { nombre: "Redes de Computadoras", prerequisitos: ["Organización de Computadoras"] },
      { nombre: "Sistemas Operativos", prerequisitos: ["Organización de Computadoras", "Introducción a la Programación"] },
      { nombre: "Programación Funcional", prerequisitos: ["Estructura de Datos"] }
    ]
  },
  {
    seccion: "Tercer Año - Quinto Cuatrimestre",
    materias: [
      { nombre: "Construcción de Interfaces de Usuario", prerequisitos: ["Programación con Objetos II"] },
      { nombre: "Algoritmos", prerequisitos: ["Programación Funcional"] },
      { nombre: "Estrategias de Persistencia", prerequisitos: ["Programación con Objetos II", "Bases de Datos"] },
      { nombre: "Laboratorio de Sistemas Operativos y Redes", prerequisitos: ["Redes de Computadoras", "Sistemas Operativos"] }
    ]
  },
  {
    seccion: "Núcleo Humanístico Obligatorio",
    materias: [
      { nombre: "Inglés I" },
      { nombre: "Inglés II", prerequisitos: ["Inglés I"] },
      { nombre: "Taller de Trabajo Intelectual" },
      { nombre: "Taller de Trabajo Universitario" }
    ]
  },
  {
    seccion: "Ciclo Superior - Sexto Cuatrimestre",
    materias: [
      { nombre: "Análisis Matemático", prerequisitos: ["Matemática II"] },
      { nombre: "Lógica y Programación", prerequisitos: ["Matemática I", "Introducción a la Programación"] },
      { nombre: "Elementos de Ingeniería de Software", prerequisitos: ["Programación con Objetos II"] },
      { nombre: "Seguridad de la Información", prerequisitos: ["Laboratorio de Sistemas Operativos y Redes"] }
    ]
  },
  {
    seccion: "Cuarto Año - Séptimo Cuatrimestre",
    materias: [
      { nombre: "Matemática III", prerequisitos: ["Análisis Matemático"] },
      { nombre: "Programación Concurrente", prerequisitos: ["Redes de Computadoras"] },
      { nombre: "Ingeniería de Requerimientos", prerequisitos: ["Elementos de Ingeniería de Software"] },
      { nombre: "Practica del Desarrollo de Software", prerequisitos: ["Construcción de Interfaces de Usuario"] }
    ]
  },
  {
    seccion: "Cuarto Año - Octavo Cuatrimestre",
    materias: [
      { nombre: "Probabilidad y Estadística", prerequisitos: ["Matemática III"] },
      { nombre: "Gestión de Proyectos de Software", prerequisitos: ["Ingeniería de Requerimientos"] },
      { nombre: "Lenguajes Formales y Autómatas", prerequisitos: ["Lógica y Programación"] }
    ]
  },
  {
    seccion: "Quinto Año - Noveno Cuatrimestre",
    materias: [
      { nombre: "Programación con Objetos III", prerequisitos: ["Programación con Objetos II"] },
      { nombre: "Teoría de la Computación", prerequisitos: ["Lenguajes Formales y Autómatas"] },
      { nombre: "Arquitectura de Software I", prerequisitos: ["Practica del Desarrollo de Software", "Gestión de Proyectos de Software", "Seguridad de la Información"] },
      { nombre: "Sistemas Distribuidos", prerequisitos: ["Programación Concurrente", "Laboratorio de Sistemas Operativos y Redes"] }
    ]
  },
  {
    seccion: "Quinto Año - Décimo Cuatrimestre",
    materias: [
      { nombre: "Características de Lenguajes de Programación", prerequisitos: ["Lógica y Programación"] },
      { nombre: "Arquitectura de Software II", prerequisitos: ["Arquitectura de Software I", "Sistemas Distribuidos"] },
      { nombre: "Arquitectura de Computadoras", prerequisitos: ["Laboratorio de Sistemas Operativos y Redes"] }
    ]
  },
  {
    seccion: "Sexto Año - Décimo Primer Cuatrimestre",
    materias: [
      { nombre: "Parseo y Generación de Código", prerequisitos: ["Lenguajes Formales y Autómatas", "Características de Lenguajes de Programación"] },
      { nombre: "Aspectos Legales y Sociales" }
    ]
  },
  {
    seccion: "Núcleo Complementario",
    materias: [
      { nombre: "Participación y Gestión en Proyectos de Software Libre" },
      { nombre: "Introducción a la Bioinformática" },
      { nombre: "Políticas Públicas en la Sociedad de la Información y la Era Digital" },
      { nombre: "Seminarios" },
      { nombre: "Introducción al Desarrollo de Videojuegos" },
      { nombre: "Bases de Datos II", prerequisitos: ["Bases de Datos"] },
      { nombre: "Sistemas de Información Geográfica" },
      { nombre: "Derechos de Autor y Derechos de Copia en la Era Digital" },
      { nombre: "Ludificación" },
      { nombre: "Semántica de Lenguajes de Programación" },
      { nombre: "Redes Neuronales" },
      { nombre: "Programación Funcional Avanzada" },
      { nombre: "Introducción a la Programación Cuántica", prerequisitos: ["Matemática III", "Características de Lenguajes de Programación"] },
      { nombre: "Ciencias de Datos" },
      { nombre: "Ciencia Ciudadana y Colaboración Abierta y Distribuida" },
      { nombre: "Calidad del Software" }
    ]
  },
  {
    seccion: "Seminario Final (Obligatorio)",
    materias: [
      { nombre: "Seminario Final" }
    ]
  }
];

function crearMalla() {
  const contenedor = document.getElementById("contenedor");

  data.forEach(seccion => {
    const seccionDiv = document.createElement("div");
    seccionDiv.className = "seccion";
    const titulo = document.createElement("h2");
    titulo.textContent = seccion.seccion;
    seccionDiv.appendChild(titulo);

    const fila = document.createElement("div");
    fila.className = "anio";

    seccion.materias.forEach(m => {
      const div = document.createElement("div");
      div.className = "materia";
      div.textContent = m.nombre;
      div.dataset.nombre = m.nombre;
      div.dataset.prerequisitos = m.prerequisitos ? JSON.stringify(m.prerequisitos) : "[]";

      div.classList.add(m.prerequisitos ? "bloqueada" : "");

      div.addEventListener("click", () => manejarClick(div));

      materias[m.nombre] = div;
      fila.appendChild(div);
    });

    seccionDiv.appendChild(fila);
    contenedor.appendChild(seccionDiv);
  });
}

function manejarClick(div) {
  if (div.classList.contains("bloqueada")) return;

  div.classList.add("aprobada");
  div.classList.remove("bloqueada");

  desbloquearMaterias();
}

function desbloquearMaterias() {
  Object.values(materias).forEach(div => {
    if (div.classList.contains("aprobada")) return;
    const requisitos = JSON.parse(div.dataset.prerequisitos);
    if (!requisitos.length) return;

    const aprobados = requisitos.every(req => materias[req]?.classList.contains("aprobada"));
    if (aprobados) div.classList.remove("bloqueada");
  });
}

crearMalla();
